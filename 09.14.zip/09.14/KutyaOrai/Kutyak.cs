﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KutyaOrai
{
    internal class Kutyak
    {
        int id;
        string name;
        string originalName;
        int fajta_id;
        int nev_id;
        int eletkor;
        DateTime utolsoOrvosi;
        string kutyaNev;

        public Kutyak(int id, string kutyaNev)
        {
            this.id = id;
            this.kutyaNev = kutyaNev;
        }

        public Kutyak(int id, string name, string originalName, int fajta_id, int nev_id, int eletkor, DateTime utolsoOrvosi, string kutyaNev)
        {
            this.id = id;
            this.name = name;
            this.originalName = originalName;
            this.fajta_id = fajta_id;
            this.nev_id = nev_id;
            this.eletkor = eletkor;
            this.utolsoOrvosi = utolsoOrvosi;
            this.kutyaNev = kutyaNev;
        }

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string OriginalName { get => originalName; set => originalName = value; }
        public int Fajta_id { get => fajta_id; set => fajta_id = value; }
        public int Nev_id { get => nev_id; set => nev_id = value; }
        public int Eletkor { get => eletkor; set => eletkor = value; }
        public DateTime UtolsoOrvosi { get => utolsoOrvosi; set => utolsoOrvosi = value; }
        public string KutyaNev { get => kutyaNev; set => kutyaNev = value; }
    }
}
